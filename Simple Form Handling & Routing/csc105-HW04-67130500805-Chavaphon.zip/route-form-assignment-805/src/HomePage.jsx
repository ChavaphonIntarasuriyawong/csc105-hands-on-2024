import React from "react";

function HomePage() {
    return (
        <>
            home
        </>
    )
}

export default HomePage;