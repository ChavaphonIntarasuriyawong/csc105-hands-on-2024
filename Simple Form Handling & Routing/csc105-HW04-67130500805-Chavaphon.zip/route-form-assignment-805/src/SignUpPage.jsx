import React from "react";

function SignUpPage() {
    return (
        <>
            SignUpPage
        </>
    )
}

export default SignUpPage;